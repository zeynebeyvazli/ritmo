// Supabase Dashboard → Project Settings → Data API / API Keys
// Buraya YALNIZ publishable key yazın. Secret / service_role açarı QƏTİ OLMAZ.
window.RITMO_CONFIG = {
  url: "https://bfimxqsdsylsycswbecs.supabase.co",
  key: "BURAYA_SB_PUBLISHABLE_KEY_YAZIN"
};
