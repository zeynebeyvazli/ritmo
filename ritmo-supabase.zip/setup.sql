-- Supabase SQL Editor-da bir dəfə icra et.
-- Əvvəl yaratdığın profiles cədvəlinə toxunmur.
create table if not exists public.user_states (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.user_states enable row level security;
drop policy if exists "Select own state" on public.user_states;
create policy "Select own state" on public.user_states for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "Insert own state" on public.user_states;
create policy "Insert own state" on public.user_states for insert to authenticated with check ((select auth.uid()) = user_id);
drop policy if exists "Update own state" on public.user_states;
create policy "Update own state" on public.user_states for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
