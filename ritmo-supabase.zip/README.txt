RITMO — İLK REAL QEYDİYYAT VERSİYASI

1) Supabase SQL Editor-da setup.sql kodunu Run et.
2) config.js faylındakı BURAYA_SB_PUBLISHABLE_KEY_YAZIN yazısını öz sb_publishable_... açarınla əvəz et. Secret/service_role açarı istifadə etmə!
3) Supabase Authentication → URL Configuration bölməsində Site URL-ni Vercel saytının tam https ünvanına dəyiş, Redirect URLs siyahısına eyni ünvanı əlavə et.
4) GitHub ritmo repository-nə index.html və config.js fayllarını yüklə; setup.sql və README.txt saytın işləməsi üçün tələb olunmur.
5) Vercel-də Deploy tamamlanmasını gözlə. HTTPS ünvanından qeydiyyatı test et və e-mail təsdiqlə.

QEYD: Coin, XP və challenge hesablamaları hələ brauzerdə edilir və data JSON kimi buludda saxlanır. Bu, təhlükəsiz iqtisadiyyat deyil. Real mükafatlar üçün server-side RPC/transaction və ayrıca coin ledger lazımdır. İcma üzvləri real deyil, AI inteqrasiyası yoxdur.
